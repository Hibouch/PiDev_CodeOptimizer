<?php

namespace App\Entity;

use App\Repository\PromotionRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;


/**
 * @ORM\Entity(repositoryClass=PromotionRepository::class)
 */
class Promotion
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="integer")
     * @Assert\NotBlank(message="Number of places is required")
     * @Assert\Positive
     * @Assert\Range(min=10,max=80,minMessage="minimum value must be 10",maxMessage="maximum value must be 80")
     */
    private $pourcentage;

    /**
     * @ORM\Column(type="datetime", nullable=true)
     * @Assert\Expression("this.getDateDebut() < this.getDateFin()")
     */
    public $date_debut;

    /**
     * @ORM\Column(type="datetime", nullable=true)
     * @Assert\Expression("this.getDateDebut() < this.getDateFin()")
     */
    public $date_fin;

    /**
     * @ORM\ManyToOne(targetEntity=Film::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $temps;

    /**
     * @ORM\ManyToOne(targetEntity=Film::class)
     */
    private $titre;



    public function getId(): ?int
    {
        return $this->id;
    }

    public function getPourcentage(): ?int
    {
        return $this->pourcentage;
    }

    public function setPourcentage(int $pourcentage): self
    {
        $this->pourcentage = $pourcentage;

        return $this;
    }

    public function getDateDebut(): ?\DateTimeInterface
    {
        return $this->date_debut;
    }

    public function setDateDebut(?\DateTimeInterface $date_debut): self
    {
        $this->date_debut = $date_debut;

        return $this;
    }

    public function getDateFin(): ?\DateTimeInterface
    {
        return $this->date_fin;
    }

    public function setDateFin(?\DateTimeInterface $date_fin): self
    {
        $this->date_fin = $date_fin;

        return $this;
    }

    public function getTemps(): ?Film
    {
        return $this->temps;
    }

    public function setTemps(?Film $temps): self
    {
        $this->temps = $temps;

        return $this;
    }

    public function getTitre(): ?Film
    {
        return $this->titre;
    }

    public function setTitre(?Film $titre): self
    {
        $this->titre = $titre;

        return $this;
    }





}
