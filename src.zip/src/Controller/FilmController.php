<?php

namespace App\Controller;

use App\Entity\Film;
use App\Entity\FiltrageParDate;
use App\Entity\PropertySearch;
use App\Form\FilmType;
use App\Form\FiltrageParDateType;
use App\Form\PropertySearchType;
use App\Repository\FilmRepository;
use App\Repository\LikeRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Knp\Component\Pager\PaginatorInterface;
use CMEN\GoogleChartsBundle\GoogleCharts\Charts\PieChart;

/**
 * @Route("/film")
 */
class FilmController extends AbstractController
{
    /**
     * @Route("/films", name="film_indexFront", methods={"GET","POST"})
     */
    public function indexFront(Request $request,FilmRepository $filmRepository , PaginatorInterface $paginator): Response
    {
        $filtrageParDate = new FiltrageParDate();
        $form = $this->createForm(FiltrageParDateType::class, $filtrageParDate);
        $form->handleRequest($request);

        $films = $paginator->paginate(
            $filmRepository->findAll(),
            $request->query->getInt('page', 1),
            6
        );

        if ($form->isSubmitted() && $form->isValid()) {
            $startDate = $filtrageParDate->getStartDate();
            $endDate = $filtrageParDate->getEndDate();



            $films = $paginator->paginate(
                $this->getDoctrine()->getRepository(Film::class)->findByDate($startDate,$endDate),
                $request->query->getInt('page', 1),
                6
            );
            return $this->render('film/indexFront.html.twig', [
                'form' =>$form->createView(),
                'films' => $films,

            ]);
        }





        return $this->render('film/indexFront.html.twig', [
            'form' =>$form->createView(),
            'films' => $films,
        ]);
    }
    /**
     * @Route("/", name="film_index", methods={"GET"})
     */
    public function index(Request $request,FilmRepository $filmRepository , PaginatorInterface $paginator): Response
    {
        $films = $paginator->paginate(
            $filmRepository->findAll(),
            $request->query->getInt('page', 1),
            3
        );

        return $this->render('film/index.html.twig', [
            'films' => $films,
        ]);
    }
    /**
     * @Route("/state", name="state", methods={"GET"})
     */
    public function stateFilm(Request $request,FilmRepository $filmRepository ): Response
    {

        $filmState = $filmRepository->findNombreSalle();

        $data = [['Salle', 'Nombre Film']];

        foreach ($filmState as $item)
            array_push($data,[$item['titre'],(int)$item['nbr']]);


        $pieChart = new PieChart();
        $pieChart->getData()->setArrayToDataTable(

            $data


        );

        $pieChart->getOptions()->setTitle('Nombre Film par Salle');
        $pieChart->getOptions()->setHeight(500);
        $pieChart->getOptions()->setWidth(900);
        $pieChart->getOptions()->getTitleTextStyle()->setBold(true);
        $pieChart->getOptions()->getTitleTextStyle()->setColor('#009900');
        $pieChart->getOptions()->getTitleTextStyle()->setItalic(true);
        $pieChart->getOptions()->getTitleTextStyle()->setFontName('Arial');
        $pieChart->getOptions()->getTitleTextStyle()->setFontSize(20);

        return $this->render('film/state.html.twig', [
           'piechart' => $pieChart,
        ]);
    }
    /**
     * @Route("/new", name="film_new", methods={"GET","POST"})
     */
    public function new(Request $request): Response
    {
        $film = new Film();
        $form = $this->createForm(FilmType::class, $film);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            $file = $film->getPicture();
            $fileName = md5(uniqid()).'.'.$file->guessExtension();
            $file->move($this->getParameter('images_directory'), $fileName);
            $film->setPicture($fileName);


            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($film);
            $entityManager->flush();

            return $this->redirectToRoute('film_index');
        }

        return $this->render('film/new.html.twig', [
            'film' => $film,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="film_show", methods={"GET"})
     */
    public function show(Film $film ,LikeRepository $likeRepository): Response
    {
        return $this->render('film/show.html.twig', [
            'film' => $film,
            'likes' => $likeRepository->findAll()
        ]);
    }

    /**
     * @Route("/{id}/edit", name="film_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, Film $film): Response
    {



        $picture = $film->getPicture();
        //on hydrate le champ du form avec le nom du fichier image
        if(!is_null($picture)){
            $film->setPicture(
                new File($this->getParameter('images_directory') . '/' . $film->getPicture())
            );

        }
        $form = $this->createForm(FilmType::class, $film);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {



            $file = $film->getPicture();
            $fileName = md5(uniqid()).'.'.$file->guessExtension();
            $file->move($this->getParameter('images_directory'), $fileName);
            $film->setPicture($fileName);

            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('film_index');
        }

        return $this->render('film/edit.html.twig', [
            'film' => $film,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="film_delete", methods={"POST","GET"} ,requirements={"id":"\d+"})
     */
   public function delete(Request $request, Film $film): Response
    {
        if ($this->isCsrfTokenValid('delete'.$film->getId(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($film);
            $entityManager->flush();
        }

        return $this->redirectToRoute('film_index');
    }
    /**
     * @Route("/search", name="search", methods={"POST","GET"})
     */
    public function search(Request $request)
    {
        $name= $request->get('dat');
        $films = $this->getDoctrine()->getManager()->getRepository(Film::class)->findTitleDQL($name);
        return $this->render('film/search.html.twig', [

            'films' => $films,
        ]);
    }



}
