<?php

namespace App\Controller;


use App\Entity\Promotion;

use App\Entity\Fidelite;
use App\Form\PromotionFormType;
use App\Repository\PromotionRepository;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
use MercurySeries\FlashyBundle\FlashyNotifier;
use phpDocumentor\Reflection\DocBlock\Serializer;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;



class PromotionController extends AbstractController
{



    /**
     * @Route("/countdown", name="countdown")
     */
    public function manager3(): Response
    {

        $rep=$this->getDoctrine()->getRepository(Promotion::class);
        $promotion=$rep->findAll();



        return $this->render('promotion/affichagecountdown.html.twig', [
            'promotion' => $promotion,
        ]);

    }


    /**
     * @Route("/promotionfront", name="promotionfront")
     */

    public function manager2(): Response
    {

        $rep=$this->getDoctrine()->getRepository(Promotion::class);
        $promotion=$rep->findAll();


        return $this->render('promotion/affichagepromotion.html.twig', [
            'promotion' => $promotion,
        ]);

    }
    /** //
     *
     * @Route("/yahala1", name="yahala1")
     */
    public function index2(): Response
    {
        return $this->render('promotion/yahala1.html.twig', [
            'controller_name' => 'PROMOTIONController',
        ]);
    }



    /**
     * @Route("/lol2", name="lol2")
     */
    public function manager(): Response
    {

        $rep=$this->getDoctrine()->getRepository(Promotion::class);
        $promotion=$rep->findAll();



        return $this->render('promotion/promotionmanager.html.twig', [
            'promotion' => $promotion,
        ]);
    }
    /**
     * @Route("/promotion_index", name="promotion_index")

     */
    public function index3(PromotionRepository $promotionRepository): Response
    {
        return $this->render('promotion/index.html.twig', [
            'promotion' => $promotionRepository->findAll(),
        ]);
    }
    /**
     * @Route("/promotioneditm{id}", name="promotioneditm")
     */
    public function edit(Request $request, Promotion $promotion,FlashyNotifier $flashy)
    {
        $form = $this->createForm(PromotionFormType::class, $promotion);
        $form->add('save',SubmitType::class);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();
            $flashy->success('Promotion modifie!', 'http://your-awesome-link.com');

            return $this->redirectToRoute('lol2');
        }

        return $this->render('promotion/edit.html.twig', [
            'promotion' => $promotion,
            'form' => $form->createView(),
        ]);
    }
    /**
     * @Route("/promotion_show{id}", name="promotion_show")
     */
    public function show(int $id): Response
    {
        $rep=$this->getDoctrine()->getRepository(Promotion::class);
        $entityManager = $this->getDoctrine()->getManager();

        $promotion=$rep->find($id);


        return $this->render('promotion/show.html.twig', [
            'promotion' => $promotion,
        ]);}
    /**
     * @Route("/promotion_detele{id}", name="promotion_delete")
     */
    public function delete(Request $request, Promotion $promotion,FlashyNotifier $flashy): Response
    {
        if ($this->isCsrfTokenValid('delete'.$promotion->getId(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($promotion);
            $entityManager->flush();
            $flashy->success('Promotion supprimee!', 'http://your-awesome-link.com');
        }

        return $this->redirectToRoute('lol2');

    }
    /**
     * @Route("/promotiona", name="promotiona")
     */
    public function new2(Request $request,FlashyNotifier $flashy)
    {
        $promotion =new Promotion();
        $form = $this->createForm(PromotionFormType::class, $promotion);
        $form->add('save',SubmitType::class);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {


            $entityManager = $this->getDoctrine()->getManager();

            $entityManager->persist($promotion);
            $entityManager->flush();
            $mail = new PHPMailer(true);

            try {

                $pourcentage = $form->get('pourcentage')->getData();


                /*$email = $form->get('emailadresse')->getData();*/

                //Server settings
                $mail->SMTPDebug = SMTP::DEBUG_SERVER;
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'souissieya2018@gmail.com';             // SMTP username
                $mail->Password   = 'Youyou2020';                               // SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;

                //Recipients
                $mail->setFrom('souissieya2018@gmail.com', 'cineholic');
                $mail->addAddress('imen.chakroun@esprit.tn', ' Nouvelle promotion');     // Add a recipient

                // Content
                $corps="Bonjour Monsieur/Madame nous avons une nouvelle promotion sur nos films de  ".$pourcentage. " % soyez les bienvenues" ;
                $mail->Subject = 'Nouvelle promotion!';
                $mail->Body    = $corps;

                $mail->send();

            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }

            $flashy->success('Promotion created!', 'http://your-awesome-link.com');
            return $this->redirectToRoute('lol2');

        }
        return $this->render('promotion/ajoutmanager.html.twig', [
            'promotion' => $promotion,
            'form' => $form->createView(),
        ]);
    }
    /**
     * @Route("/sortbypourcentageasc", name="sortbypourcentageasc")
     */
    public function sortByPourcentageASC(): Response
    {

        $rep=$this->getDoctrine()->getRepository(Promotion::class);
        $promotion=$rep->sortByPourcentageASC();


        return $this->render('promotion/promotionmanager.html.twig', [
            'promotion' => $promotion,
        ]);
    }



}