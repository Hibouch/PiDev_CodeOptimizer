<?php

namespace App\Controller;

use App\Entity\Fidelite;
use App\Form\FideliteType;
use App\Repository\FideliteRepository;
use MercurySeries\FlashyBundle\FlashyNotifier;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Dompdf\Dompdf;
use Dompdf\Options;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;



class FideliteController extends AbstractController
{


    /**
     * @Route("/fidelitefront", name="fidelitefront")
     */
    public function manager1(FlashyNotifier $flashy): Response
    {

        $rep=$this->getDoctrine()->getRepository(Fidelite::class);
        $fidelite=$rep->findAll();

        $flashy->success('Felicitations vous avez gagnez un coupon de reduction de 10 % votre code promo est le suivant : cine123 !', 'http://your-awesome-link.com');

        return $this->render('fidelite/affichagefidelite.html.twig', [
            'fidelite' => $fidelite,
        ]);

    }

    /** //
     *
     * @Route("/yahala1", name="yahala1")
     */
    public function index2(): Response
    {
        return $this->render('fidelite/yahala1.html.twig', [
            'controller_name' => 'FIDELITEController',
        ]);
    }

    /**
     * @Route("/ref", name="ref")
     */
    public function manager(): Response
    {

        $rep=$this->getDoctrine()->getRepository(Fidelite::class);
        $fidelite=$rep->findAll();



        return $this->render('fidelite/fidelitemanager.html.twig', [
            'fidelite' => $fidelite,
        ]);
    }
    /**
     * @Route("/fidelite_index", name="fidelite_index")

     */
    public function index3(FideliteRepository $fideliteRepository): Response
    {
        return $this->render('fidelite/index.html.twig', [
            'fidelite' => $fideliteRepository->findAll(),
        ]);
    }
    /**
     * @Route("/fideliteedit{ref}", name="fidelite_edit")
     */
    public function edit(Request $request, Fidelite $fidelite,FlashyNotifier $flashy)
    {
        $form = $this->createForm(FideliteType::class, $fidelite);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();
            $flashy->success('Fidelite modifie!', 'http://your-awesome-link.com');

            return $this->redirectToRoute('ref');
        }

        return $this->render('fidelite/edit.html.twig', [
            'fidelite' => $fidelite,
            'form' => $form->createView(),
        ]);
    }
    /**
     * @Route("/fidelite_show{ref}", name="fidelite_show")
     */
    public function show(int $ref): Response
    {
        $rep=$this->getDoctrine()->getRepository(Fidelite::class);
        $entityManager = $this->getDoctrine()->getManager();

        $fidelite=$rep->find($ref);


        return $this->render('fidelite/show.html.twig', [
            'fidelite' => $fidelite,
        ]);}
    /**
     * @Route("/fidelite_detele{ref}", name="fidelite_delete")
     */
    public function delete(Request $request, Fidelite $fidelite,FlashyNotifier $flashy): Response
    {
        if ($this->isCsrfTokenValid('delete'.$fidelite->getRef(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($fidelite);
            $entityManager->flush();
            $flashy->success('Fidelite supprimee!', 'http://your-awesome-link.com');
        }

        return $this->redirectToRoute('ref');

    }
    /**
     * @Route("/new", name="fidelite_new")
     */
    public function new(Request $request,FlashyNotifier $flashy)
    {
        $fidelite =new Fidelite();
        $form = $this->createForm(FideliteType::class, $fidelite);


        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {


            $entityManager = $this->getDoctrine()->getManager();

            $entityManager->persist($fidelite);
            $entityManager->flush();

            $flashy->success('Fidelite created!', 'http://your-awesome-link.com');
            return $this->redirectToRoute('ref');

        }
        return $this->render('fidelite/new.html.twig', [
            'fidelite' => $fidelite,
            'form' => $form->createView(),
        ]);
    }



    /**
     * @Route("/listu1", name="listu1", methods={"GET"})
     */
    public function listu1(FideliteRepository  $fideliteRepository): Response
    {
        // Configure Dompdf according to your needs
        $pdfOptions = new Options();
        $pdfOptions->set('defaultFont', 'Arial');

        // Instantiate Dompdf with our options
        $dompdf = new Dompdf($pdfOptions);
        // Retrieve the HTML generated in our twig file
        $html = $this->renderView('fidelite\pdf.html.twig', [
            'fidelite' =>$fideliteRepository->findAll(),
        ]);

        // Load HTML to Dompdf
        $dompdf->loadHtml($html);

        // (Optional) Setup the paper size and orientation 'portrait' or 'portrait'
        $dompdf->setPaper('A3', 'portrait');

        // Render the HTML as PDF
        $dompdf->render();
        // Output the generated PDF to Browser (inline view)
        $dompdf->stream("mypdf.pdf", [
            "Attachment" => false
        ]);
    }
}
