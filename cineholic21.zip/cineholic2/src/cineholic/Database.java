package cineholic;

import java.sql.Connection;
import java.sql.DriverManager;

public class Database {
	public static Connection connect() {
		Connection connection = null;
		String URL = "jdbc:mysql://localhost/cineholic";
		try {
			connection = DriverManager.getConnection(URL,"root","");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}
}
