/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cineholic;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.StringConverter;

/**
 * FXML Controller class
 *
 * @author amine
 */
public class FXMLController implements Initializable {

    @FXML
    private TextField TFNom;
    @FXML
    private TextField TFCapacite;
    @FXML
    private TextField TFLocalisation;
    @FXML
    private TableView<SalleDeCinema> TVCinema;
    @FXML
    private TableColumn<SalleDeCinema, Integer> id;
    @FXML
    private TableColumn<SalleDeCinema, String> nom;
    @FXML
    private TableColumn<SalleDeCinema, Integer> capacite;
    @FXML
    private TableColumn<SalleDeCinema, String> localisation;
    @FXML
    private Button BAjouter;
   
    @FXML
    private Button BSupprimer;
    ObservableList<SalleDeCinema> CinemaList;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    	
        // TODO
        CinemaList = FXCollections.observableList(SalleDeCinema.findAll());
        nom.setCellFactory(TextFieldTableCell.forTableColumn());
        capacite.setCellFactory(TextFieldTableCell.forTableColumn(new StringConverter<Integer>() {
            @Override
            public String toString(Integer object) {
                return Integer.toString(object);
            }

            @Override
            public Integer fromString(String string) {
                int a = 0;
                try {
                    a = Integer.parseInt(string);
                } catch (Exception e) {

                }
                return a;
            }
        }));
        localisation.setCellFactory(TextFieldTableCell.forTableColumn());
        nom.setOnEditCommit(new EventHandler<CellEditEvent<SalleDeCinema, String>>() {
            @Override
            public void handle(CellEditEvent<SalleDeCinema, String> t) {
                SalleDeCinema salle = ((SalleDeCinema) t.getTableView().getItems().get(t.getTablePosition().getRow()));
                salle.setNom(t.getNewValue());
                SalleDeCinema.update(salle);
            }
        }
        );
        capacite.setOnEditCommit(new EventHandler<CellEditEvent<SalleDeCinema, Integer>>() {
            @Override
            public void handle(CellEditEvent<SalleDeCinema, Integer> t) {
                SalleDeCinema salle = t.getTableView().getItems().get(t.getTablePosition().getRow());
                salle.setCapacite(t.getNewValue());
                SalleDeCinema.update(salle);
            }
        }
        );
        localisation.setOnEditCommit(new EventHandler<CellEditEvent<SalleDeCinema, String>>() {
            @Override
            public void handle(CellEditEvent<SalleDeCinema, String> t) {
                SalleDeCinema salle = t.getTableView().getItems().get(t.getTablePosition().getRow());
                salle.setLocalisation(t.getNewValue());
                SalleDeCinema.update(salle);
            }
        }
        );
        BSupprimer.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                SalleDeCinema salle = (SalleDeCinema)TVCinema.getSelectionModel().getSelectedItem();
                if (salle == null){
                    Alert errorAlert = new Alert(AlertType.ERROR);
                    errorAlert.setHeaderText("Erreur");
                    errorAlert.setContentText("Veuillez selectionnez une salle à supprimer");
                    errorAlert.showAndWait();
                }
                else{
                    SalleDeCinema.delete(salle.getId());
                    CinemaList.remove(TVCinema.getSelectionModel().getSelectedIndex());
                }
            }
        });
    
        BAjouter.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                String nom = TFNom.getText();
                String capaciteText = TFCapacite.getText();
                String localisation = TFLocalisation.getText();
                if (nom.isEmpty() || capaciteText.isEmpty() || localisation.isEmpty()){
                    Alert errorAlert = new Alert(AlertType.ERROR);
                    errorAlert.setHeaderText("Erreur");
                    errorAlert.setContentText("Veuillez saisir les informations de la salle");
                    errorAlert.showAndWait();
                }
                else{
                    int capacite;
                    try{
                        capacite = Integer.parseInt(capaciteText);
                    }
                    catch(NumberFormatException o){
                        Alert errorAlert = new Alert(AlertType.ERROR);
                        errorAlert.setHeaderText("Erreur");
                        errorAlert.setContentText("La capacité est un entier!");
                        errorAlert.showAndWait();
                        return;
                    }
                    SalleDeCinema salle = new SalleDeCinema(nom, capacite, localisation);
                    CinemaList.add(SalleDeCinema.insert(salle));
                }
            }
        });
        TVCinema.setItems(CinemaList);
    }
}
