package cineholic;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import javax.swing.JTextField;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openstreetmap.gui.jmapviewer.Demo;

import javafx.stage.Stage;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SearchCinema {

public static JFrame frame;
	private JTextField textField;
	public static BufferedReader br = null;
	public static BufferedReader br2 = null;
	public static ArrayList<SalleDeCinema> list=new ArrayList<SalleDeCinema>(); 
	private JButton btnNewButton_1;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		 SearchCinema search = new SearchCinema();
         search.frame.setVisible(true);
	}

	/**
	 * Create the application.
	 */
	public SearchCinema() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public static void getData(String cityName) {
		try {
			
			URL url = new URL("https://api.geoapify.com/v1/geocode/search?text=38%20"+cityName+"%20Tunisia&apiKey=422b1738ff6d445d9cd69ae4089aa7ee");
			HttpURLConnection http = (HttpURLConnection)url.openConnection();
			http.setRequestProperty("Accept", "application/json");
			
			if (100 <= http.getResponseCode() && http.getResponseCode() <= 399) {
			    br = new BufferedReader(new InputStreamReader(http.getInputStream(),"UTF-8"));
			} else {
			    br = new BufferedReader(new InputStreamReader(http.getErrorStream()));
			}
			String str =br.readLine();
			JSONObject json = new JSONObject(str);  
			String strToFetching= json.getJSONArray("features").getJSONObject(0).get("bbox").toString();
			String ATT1=strToFetching.substring(strToFetching.indexOf("[")+1,strToFetching.indexOf(","));
		String ATT2=strToFetching.substring(strToFetching.indexOf(",")+1,strToFetching.substring(strToFetching.indexOf(",")).lastIndexOf(","));
			String ATT3V1=strToFetching.substring(
				strToFetching.lastIndexOf(strToFetching.substring(strToFetching.indexOf(","),strToFetching.lastIndexOf(","))),strToFetching.lastIndexOf(',')
				);
			
			
			
			
			String ATT3=ATT3V1.substring(ATT3V1.lastIndexOf(",")+1);
			String ATT4=strToFetching.substring(strToFetching.lastIndexOf(",")+1,strToFetching.lastIndexOf("]"));
			
			System.out.println(strToFetching);
			System.out.println(ATT1);
			System.out.println(ATT2);
			System.out.println(ATT3);
			System.out.println(ATT4);
			
			
			URL url2 = new URL("https://api.geoapify.com/v2/places?categories=entertainment.cinema&filter=rect%3A"+ATT1+"%2C"+ATT2+"%2C"+ATT3+"%2C"+ATT4+"&limit=20&apiKey=422b1738ff6d445d9cd69ae4089aa7ee");
			
			HttpURLConnection http2 = (HttpURLConnection)url2.openConnection();
			http2.setRequestProperty("Accept", "application/json");
			
			if (100 <= http2.getResponseCode() && http2.getResponseCode() <= 399) {
			    br2 = new BufferedReader(new InputStreamReader(http2.getInputStream(),"UTF-8"));
			} else {
			    br2 = new BufferedReader(new InputStreamReader(http2.getErrorStream()));
			}
			String str2 =br2.readLine();
			JSONObject json2 = new JSONObject(str2);  
			JSONArray strToFetching2= json2.getJSONArray("features");
			//System.out.println(strToFetching2);
		for(int i=0; i<strToFetching2.length();i++) {
			String objectCinema=strToFetching2.getJSONObject(i).getJSONObject("geometry").get("coordinates").toString();
			String objectCinemaName=strToFetching2.getJSONObject(i).getJSONObject("properties").get("name").toString();
			//System.out.println(objectCinemaName);
	        String LONG=objectCinema.substring(objectCinema.indexOf("[")+1,objectCinema.indexOf(","));
		    String LAT=objectCinema.substring(objectCinema.indexOf(",")+1,objectCinema.lastIndexOf("]"));
			//System.out.println(objectCinema);
			SalleDeCinema SalleCinema= new SalleDeCinema(objectCinemaName,Double.valueOf(LONG),Double.valueOf(LAT));
			
	       list.add(SalleCinema);
	       
	      
		}
		 // System.out.println(list);
					
			
			
		//	System.out.println(LONG);
			//System.out.println(LAT);
			http.disconnect();
			http2.disconnect();
			Demo map = new Demo(list);
			map.setVisible(true);
			
		
			
			
			
		}
		
		
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 473, 324);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Please enter your City to search cinema");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel.setBounds(118, 95, 253, 37);
		frame.getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(118, 143, 237, 27);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				getData(textField.getText());
				
			}
		});
		btnNewButton.setBounds(201, 181, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setBounds(20, 213, 89, 23);
		frame.getContentPane().add(btnNewButton_1);
	}
}
