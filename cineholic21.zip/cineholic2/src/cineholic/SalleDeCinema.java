package cineholic;

import java.sql.*;
import java.util.ArrayList;

public class SalleDeCinema {

    static Connection connection = Database.connect();
    private int id, capacite;
    private String nom, localisation;
    public  Double lon;
    public Double lat;

    SalleDeCinema() {
        this.id = -1;
    }
    SalleDeCinema(String nom,Double lon,Double lat) {
    	this.nom=nom;
    	this.lon=lon;
    	this.lat=lat;
    	
    }
    SalleDeCinema(String nom, int capacite, String localisation) {
        this.id = -1;
        this.nom = nom;
        this.capacite = capacite;
        this.localisation = localisation;
    }

    SalleDeCinema(int id, String nom, int capacite, String localisation) {
        this.id = id;
        this.nom = nom;
        this.capacite = capacite;
        this.localisation = localisation;
    }

    public String toString() {
        return "SalleDeCinema [id=" + id + ", nom=" + nom + ", capacite=" + capacite + ", localisation=" + localisation
                + "]";
    }

    public static SalleDeCinema insert(SalleDeCinema salle) {
        String query = "INSERT INTO SalleDeCinema (nom, capacite, localisation) VALUES('"
                + salle.nom + "', " + salle.capacite + ",'" + salle.localisation + "');";
        try {
            PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
             int affectedRows = statement.executeUpdate();
             if (affectedRows == 0) {
                throw new SQLException("Creating user failed");
             }
             try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    salle.setId(generatedKeys.getInt(1));
                }
                else throw new SQLException("Creating user failed");
        }
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
        return salle;
    }

    public static boolean delete(int id) {
        String query = "DELETE FROM SalleDeCinema WHERE id = " + id;
        try {
            Statement st = connection.createStatement();
            st.executeUpdate(query);
        } catch (Exception e) {
            System.out.println(e);
            return false;
        }
        return true;
    }

    public static boolean deleteAll() {
        String query = "DELETE FROM SalleDeCinema";
        try {
            Statement st = connection.createStatement();
            st.executeUpdate(query);
        } catch (Exception e) {
            System.out.println(e);
            return false;
        }
        return true;
    }

    public static boolean update(SalleDeCinema salle) {
        String query = "UPDATE SalleDeCinema SET nom = '" + salle.nom
                + "', capacite = " + salle.capacite + ", localisation = '" + salle.localisation + "' WHERE id = " + salle.id;
        try {
            Statement st = connection.createStatement();
            st.executeUpdate(query);
        } catch (Exception e) {
            System.out.println(e);
            return false;
        }
        return true;
    }

    public static SalleDeCinema find(int id) {
        SalleDeCinema salle = null;
        String query = "SELECT * FROM SalleDeCinema WHERE id = " + id;
        try {
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(query);
            if (rs.next()) {
                salle = new SalleDeCinema(rs.getInt("id"), rs.getString("nom"), rs.getInt("capacite"), rs.getString("localisation"));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return salle;
    }

    public static ArrayList<SalleDeCinema> findAll() {
        ArrayList<SalleDeCinema> salles = new ArrayList<SalleDeCinema>();
        String query = "SELECT * FROM SalleDeCinema";
        try {
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                salles.add(new SalleDeCinema(rs.getInt("id"), rs.getString("nom"), rs.getInt("capacite"), rs.getString("localisation")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return salles;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCapacite() {
        return capacite;
    }

    public void setCapacite(int capacite) {
        this.capacite = capacite;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getLocalisation() {
        return localisation;
    }

    public void setLocalisation(String localisation) {
        this.localisation = localisation;
    }
    public Double getLon() {
  		return lon;
  	}

  	public void setLon(Double lon) {
  		this.lon = lon;
  	}

  	public Double getLat() {
  		return lat;
  	}

  	public void setLat(Double lat) {
  		this.lat = lat;
  	}
}
