/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.esprit.services;
import java.util.List;
/**
 *
 * @author 
 * * @param < T >
 */
public interface Service2<T> {
     public void ajouterPromo(T t);
    public void supprimerPromo(T t);
    public void modifierPromo(int id,int pourcentage ,String date_debut,String date_fin );
   public List<T> afficherPromo(); 
}
