/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.esprit.services;
import com.esprit.models.Promo;
import com.esprit.utils.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 
 */
public class ServicePromo  implements Service2<Promo>{
    Connection cnx = DataSource.getInstance().getCnx();
    private Statement ste;
    private PreparedStatement ps;
    private ResultSet rs;


    @Override
    public void ajouterPromo(Promo t) {
        try {
            String requete = "INSERT INTO promotion (id_promo,pourcentage,date_debut,date_fin) VALUES (?,?,?,?)";
            PreparedStatement evt = cnx.prepareStatement(requete);
            evt.setInt(1, t.getId_promo());
            evt.setInt(2, t.getPourcentage());
            evt.setString(3, t.getDateDebut());
            evt.setString(4, t.getDateFin());
            evt.executeUpdate();
            System.out.println("promotion ajoutée !");

        } catch (SQLException ex) {
            Logger.getLogger(ServicePromo.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public void supprimerPromo(Promo t) {
        try {
            String requete = "DELETE FROM promotion WHERE id_promo=?";
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setInt(1, t.getId_promo());
            pst.executeUpdate();
            System.out.println("promotion supprimée !");

        } catch (SQLException ex) {
            Logger.getLogger(ServicePromo.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public void modifierPromo(int id_promo ,int pourcentage ,String date_debut,String date_fin) {
        try {
            String requete = "UPDATE event SET pourcentage=?,date_debut=?,date_fin=? WHERE id_promo=?";
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setInt(4,id_promo);
            pst.setInt(1,pourcentage);
            pst.setString(2,date_debut);
            pst.setString(3,date_fin);
            pst.executeUpdate();
          
            System.out.println("promotion modifiée !");

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public List<Promo> afficherPromo() {
        List<Promo> list = new ArrayList<>();

        try {
            String requete = "SELECT * FROM promotion";
            PreparedStatement pst = cnx.prepareStatement(requete);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                list.add(new Promo(rs.getInt("id_promo"), rs.getInt("pourcentage"), rs.getString("date_debut"),rs.getString("date_fin")));
            }

        } catch (SQLException ex) { 
            System.err.println(ex.getMessage());
        }

        return list;
    } 
    
}
