/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.esprit.services;
import com.esprit.models.fidelite;
import com.esprit.utils.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


/**
 *
 * @author 
 */

public class ServiceFidelite implements IService<fidelite> {
    Connection cnx = DataSource.getInstance().getCnx();
    private Statement ste;
    private PreparedStatement ps;
    private ResultSet rs;


    @Override
    public void ajouter(fidelite t) {
        try {
            String requete = "INSERT INTO fidelite (ref,id_client,point) VALUES (?,?,?)";
            PreparedStatement evt = cnx.prepareStatement(requete);
            
            evt.setString(1, t.getref());
            evt.setInt(2, t.getid_client());
            evt.setInt(3, t.getpoint());
            evt.executeUpdate();
            System.out.println("fidelite ajoutée !");

        } catch (SQLException ex) {
            Logger.getLogger(ServiceFidelite.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public void supprimer(fidelite t) {
        try {
            String requete = "DELETE FROM fidelite WHERE ref=?";
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setString(1, t.getref());
            pst.executeUpdate();
            System.out.println("fidelite supprimée !");

        } catch (SQLException ex) {
            Logger.getLogger(ServiceFidelite.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println(ex.getMessage());
        }
    }

    //@Override
    
    public void modifier( String ref ,int id_client,int point) {
        try {
            String requete = "UPDATE fidelite SET id_client=?,point=?, WHERE ref=?";
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setString(3,ref);
            pst.setInt(1,id_client);
            pst.setInt(2,point);
            pst.executeUpdate();
          
            System.out.println("fidelite modifiée !");

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public List<fidelite> afficher() {
        List<fidelite> list = new ArrayList<>();

        try {
            String requete = "SELECT * FROM fidelite";
            PreparedStatement pst = cnx.prepareStatement(requete);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                list.add(new fidelite(rs.getString("ref"), rs.getInt("id_client"), rs.getInt("point")));
            }

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }

        return list;
    } 
     public ObservableList<fidelite> tricro() {
       ObservableList <fidelite> list = FXCollections.observableArrayList();
       String req="select * from fidelite Order By point ASC";
        try {
            ste=cnx.createStatement();
            rs=ste.executeQuery(req);
            while(rs.next()){
               String ref= rs.getString("ref");
               int id_client=rs.getInt("id_client");
               int point=rs.getInt("point");
               fidelite e  = new fidelite( ref,id_client,point);
               e.setref(ref);
               list.add(e);
              
            }
            
        } catch (SQLException ex) {
            System.out.println("erreur");
        }
        return list; 
     }
        
    public ObservableList<fidelite> tridec() {
       ObservableList <fidelite> list = FXCollections.observableArrayList();
       String req="select * from fidelite Order By point DESC ";
        try {
            ste=cnx.createStatement();
            rs=ste.executeQuery(req);
           while(rs.next()){
               String ref= rs.getString("ref");
               int id_client=rs.getInt("id_client");
               int point=rs.getInt("point");
               fidelite e  = new fidelite( ref,id_client,point);
               e.setref(ref);
               list.add(e);
               list.add(e);
              
            }
            
        } catch (SQLException ex) {
            System.out.println("erreur");
        }
        return list; 
    }
       public ObservableList<fidelite> listerRecherche (String recherche) {
       ObservableList <fidelite> list = FXCollections.observableArrayList();
        String req = "SELECT * FROM fidelite WHERE ref like '%" + recherche + "%' or id_client like'%" + recherche  + "%'or point  like '%" + recherche +"%' ";
         
        try {
            ste=cnx.createStatement();
            rs=ste.executeQuery(req);
            while(rs.next()){
               String ref= rs.getString("ref");
               int id_client=rs.getInt("id_client");
               int point=rs.getInt("point");
               
              
                //list.add(new Societe(Id , nom, tel ,adresse,image));
                fidelite e  = new fidelite( ref, id_client, point);
               e.setref(ref);
               list.add(e);
               
            }
            
        } catch (SQLException ex) {
            System.out.println("erreur");
        }
         
         return list;   
    }  

    @Override
    public void modifier(int id, String nom, String date_debut, String date_fin) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

 
}
