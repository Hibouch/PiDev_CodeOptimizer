/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.esprit.tests;

import com.esprit.models.fidelite;
import com.esprit.services.ServiceFidelite;


import com.esprit.models.Promo;
import com.esprit.services.ServicePromo;

/**
 *
 * @author 
 */
public class MainProg {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ServiceFidelite ev = new ServiceFidelite();
        ServicePromo pr =new ServicePromo();
       
   
  System.out.println(ev.listerRecherche("10/12/2202"));
         
         
        
    }
}

   
