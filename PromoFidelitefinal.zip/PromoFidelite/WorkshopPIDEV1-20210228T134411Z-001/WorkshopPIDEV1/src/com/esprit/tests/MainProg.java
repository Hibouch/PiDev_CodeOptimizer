/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.esprit.tests;

import com.esprit.models.fidelite;
import com.esprit.services.ServiceFidelite;


import com.esprit.models.Promo;
import com.esprit.services.ServicePromo;

/**
 *
 * @author 
 */
public class MainProg {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ServiceFidelite fi = new ServiceFidelite();
        ServicePromo pr =new ServicePromo();
        //fidelite
 //fi.ajouter(new fidelite("71",50,100));
 //fi.afficher().forEach(System.out::println);
// fi.modifierfidelite("71",102,50);
 /*fidelite e=new fidelite("71",10,100);
 fi.supprimer(e);*/
//System.out.println(fi.listerRecherche("71"));
//System.out.println(fi.tricro());
//System.out.println(fi.tridec());



       //promotion
//pr.ajouterPromo(new Promo (30,"07/12/2020","12/10/2520"));
//pr.afficherPromo().forEach(System.out::println);
//pr.modifierPromo(1,10,"2","5");
//Promo p=new Promo (10,"2","5");
//pr.supprimerPromo(p);
//System.out.println(pr.listerRecherche("12/25/25"));
//System.out.println(pr.tricro());
//System.out.println(pr.tricro());



 
   
 
         
         
        
    }
}

   
