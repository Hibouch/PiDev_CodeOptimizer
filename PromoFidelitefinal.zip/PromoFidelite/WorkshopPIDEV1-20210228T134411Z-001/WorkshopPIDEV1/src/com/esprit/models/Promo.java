/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.esprit.models;

/**
 *
 * @author 
 */
public class Promo {
     private int id_promo;
    private int pourcentage;
    private String date_debut ;
    private String date_fin ;

    public Promo(int id_promo, int pourcentage , String date_debut, String date_fin) {
        this.id_promo = id_promo;
        this.pourcentage = pourcentage;
        this.date_debut = date_debut;
        this.date_fin = date_fin;
    }
    public Promo( int pourcentage , String date_debut, String date_fin) {
    
        this.pourcentage = pourcentage;
        this.date_debut = date_debut;
        this.date_fin = date_fin;
    }

  

    public int getId_promo() {
        return id_promo;
    }

    public void setId_promo(int id_promo) {
        this.id_promo = id_promo;
    }

    public int getPourcentage() {
        return pourcentage;
    }

    public void setPourcentage(int pourcentage) {
        this.pourcentage =pourcentage;
    }

    public String getDateDebut() {
        return date_debut;
    }

    public void setDateDebut(String date_debut) {
        this.date_debut = date_debut;
    }
    public String getDateFin() {
        return date_fin;
    }

    public void setDateFin(String date_fin) {
        this.date_fin = date_fin;
    }

    @Override
    public String toString() {
        return "Promo{" + "id_promo=" + id_promo + ", pourcentage=" + pourcentage + ", date debut="+ date_debut + ",date fin=" + date_fin+ '}';
        
    }
}
