/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.esprit.models;

/**
 *
 * @author 
 */
public class fidelite { 
    private String ref;
    private int id_client;
    private  int point ;
  

    public fidelite(String ref, int id_client, int point) {
        this.ref = ref;
        this.id_client = id_client;
        this.point = point;
      
    }
     public fidelite( int id_client, int point) {
        this.id_client = id_client;
        this.point = point;
      
    }
    

    public String getref() {
        return ref;
    }

    public void setref(String ref) {
        this.ref = ref;
    }

    public int getid_client() {
        return id_client;
    }

    public void setid_client(int id_client) {
        this.id_client= id_client;
    }

    public int getpoint() {
        return point;
    }

    public void setpoint(int point) {
        this.point = point;
    }
    
     @Override
    public String toString() {
        return "fidelite{" + "ref=" + ref + ", id_client=" + id_client + ", point=" + point + ')';
    }


   /* @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final fidelite other = (fidelite) obj;
        if (this.ref != other.ref) {
            return false;
        }
        return true;
    }*/
}
