/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.esprit.services;

import com.esprit.models.Fidelite;
//import com.esprit.models.Promotion;
import com.esprit.utils.DataSource;
import doryan.windowsnotificationapi.fr.Notification;
import java.awt.AWTException;
import java.awt.TrayIcon;
import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author infoMix
 */
public class ServiceFidelite {
     Connection cnx = DataSource.getInstance().getCnx();
    private Statement stm;
    //private PreparedStatement pst;
    private ResultSet rs;
         private PreparedStatement pst;
     int ref  ;
     int id_client ;
     int point ;


    public void Ajouter(Fidelite t) throws MalformedURLException 
    {
        try {
          
            String req="INSERT INTO fidelite (ref,id_client,point) VALUES (?,?,?)";
            PreparedStatement pst=cnx.prepareStatement(req);
            pst.setInt(1,t.getRef());
            pst.setInt(2,t.getId_client());
            pst.setInt(3,t.getPoint());
           
            
            pst.executeUpdate();
                    System.out.println("cbn");

        } catch (SQLException ex) {
//            Logger.getLogger(ServiceEvent.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("mcbnch"); 
        }
         try {
                Notification.sendNotification("Success", "fidelite added  with successful",TrayIcon.MessageType.INFO);
            } catch (AWTException ex) {
                Logger.getLogger(ServiceFidelite.class.getName()).log(Level.SEVERE, null, ex); 
             }   
                
    }
    public ObservableList<Fidelite> lister() throws MalformedURLException{
           ObservableList<Fidelite> list1 =FXCollections.observableArrayList();
           String requete="SELECT ref,id_client,point) FROM fidelite";
            try {
                PreparedStatement pst = cnx.prepareStatement(requete)  ; 
                 ResultSet rs = pst.executeQuery();
                    while (rs.next()){
                     list1.add
        (new Fidelite(rs.getInt(1),rs.getInt(2),rs.getInt(3)));
                 
                     }
                System.out.println("lister fidelite");
                }  
            catch (SQLException ex) {
            
            } 
       
     return list1;
    
    }
 
    public void Modifier(Fidelite t) throws MalformedURLException 
    {
       
          try {
              
              String sql = "UPDATE fidelite SET id_client=?,point=? WHERE ref=?";
              PreparedStatement statement = cnx.prepareStatement(sql,PreparedStatement.RETURN_GENERATED_KEYS);
              try {
                  
                  statement.setInt(1, t.getRef());
                  statement.setInt(2,t.getId_client());
                  statement.setInt(3,t.getPoint());

                  System.out.println(statement);
                  statement.executeUpdate();
                  System.out.println("update done");
              } catch (SQLException ex) {
                  Logger.getLogger(ServiceFidelite.class.getName()).log(Level.SEVERE, null, ex);
              }
              
          } catch (SQLException ex) {
            Logger.getLogger(ServiceFidelite.class.getName()).log(Level.SEVERE, null, ex);
        } 
          
          try {
                Notification.sendNotification("Success", "FIDELITE modified with successful",TrayIcon.MessageType.INFO);
            } catch (AWTException ex) {
                Logger.getLogger(ServicePromotion.class.getName()).log(Level.SEVERE, null, ex); 
             } 
          
       
    }
    
    /**
     *
     * @param e
     * @throws SQLException
     */
    
    public void Supprimer(Fidelite e) throws SQLException, MalformedURLException 
    { 
    
 try { 
            String delete = "DELETE FROM fidelite WHERE ref = ? ";
        PreparedStatement st2 = cnx.prepareStatement(delete);
        int reff = e.getRef();
        
        st2.setInt(1,reff);
        st2.executeUpdate();
       

        } catch (SQLException ex) {
            Logger.getLogger(ServiceFidelite.class.getName()).log(Level.SEVERE, null, ex);
        }
 

      try {
                Notification.sendNotification("Success", "fidelite deleted with successful",TrayIcon.MessageType.INFO);
            } catch (AWTException ex) {
                Logger.getLogger(ServiceFidelite.class.getName()).log(Level.SEVERE, null, ex); 
             }

    }
    
    
 

    public List<Fidelite> Afficher() {
        List<Fidelite> l = new ArrayList<>();
         
         
      
        try {
            String req="SELECT * FROM fidelite Order By ref ASC";
            stm=cnx.createStatement();
            rs=stm.executeQuery(req);
            while(rs.next())
            {

                Fidelite e = new Fidelite();
                 e.setRef(rs.getInt("ref"));
                 e.setId_client(rs.getInt("id_client"));
                 e.setPoint(rs.getInt("point"));
                System.out.println(e);

                l.add(e);

            }
        } catch (SQLException ex) {
            Logger.getLogger(ServiceFidelite.class.getName()).log(Level.SEVERE, null, ex);
        }
        return l;
    }

   


   
   

  

    

}
