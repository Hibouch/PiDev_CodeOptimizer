/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.esprit.models;



/**
 *
 * @author infoMix
 */
public class Fidelite {
    int ref ;
    int id_client ;
    int point ;
    

 public Fidelite() {
    }
public Fidelite(int ref, int id_client, int point) {
        this.ref = ref;
        this.id_client = id_client;
        this.point = point;
      
    }

    public int getRef() {
        return ref;
    }

    public void setRef(int ref) {
        this.ref = ref;
    }

    public int getId_client() {
        return id_client;
    }

    public void setId_client(int id_client) {
        this.id_client = id_client;
    }

    public int getPoint() {
        return point;
    }

    public void setPoint(int points) {
        this.point = points;
    }

   

    
}