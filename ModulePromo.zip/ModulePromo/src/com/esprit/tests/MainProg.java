/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.esprit.tests;

import com.esprit.models.Promotion;
import com.esprit.services.ServicePromotion;



/**
 *
 * @author imen
 */
public class MainProg {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ServicePromotion se = new ServicePromotion();
        //ServicePromo pr =new ServicePromo();
        
       
    /*Event   e55=new Event(1,"hjjjk","156525","5556");
         ev.afficher().forEach(System.out::println);
         ev1.afficher().forEach(System.out::println);
          ev2.afficher().forEach(System.out::println);
         //ev.modifier(1,"happy hour","12/10/2020","13/10/2022");
         //ev.supprimer(e55);*/
         
    // ev.ajouter(new Event ("happy","10/12/2202","12/12/42"));
     //Event e= new Event ("happy","10/12/2202","12/12/42");
     //ev.supprimer( e,1);
  /*System.out.println(ev.listerRecherche("10/12/2202"));*/
  //pr.ajouterPromo(new Promo(10,"10/10/2021","11/10/2021")); 
  //pr.afficherPromo().forEach(System.out::println);     
  //pr.modifierPromo(1, 20,"20", "20");
  /*ev.ajouter(new Event ("happy hour","10/12/2020","11/12/2020"));
  ev.ajouter(new Event ("black friday","29/10/2020","31/10/"));
  ev.ajouter(new Event ("happy new year","30/12/2020","01/01/2021"));*/
  //ev.modifier(2,"black friday","29//10/2020","31/10/2020");
 /* Event e= (new Event("happy new year","30/12/2020","01/01/2021")); 
  ev.supprimer(e, 3);*/
  
 // System.out.println(ev.listerRecherche("happy hour"));
// System.out.println(ev.tridec());
 
  
  
  
  
  
    
        
    }
}

   
