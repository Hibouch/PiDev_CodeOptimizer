/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;
import com.esprit.utils.DataSource;
import com.esprit.models.Fidelite;
import com.esprit.services.ServiceFidelite;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.scene.control.TextField;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.net.URL;
import java.sql.Connection;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javax.sql.rowset.serial.SerialArray;

/**
 * FXML Controller class
 *
 * @author infoMix
 */
public class FideliteController implements Initializable {
    
     int index = -1;
    @FXML
    private TableView<Fidelite> tvFidelite;
    @FXML private TableColumn<Fidelite, Integer> ref;
    @FXML private TableColumn<Fidelite, Integer> id_client;
    @FXML private TableColumn<Fidelite,Integer > point;
    @FXML private Button add;
    @FXML private Button Modifiy;
    @FXML private Button remove;
    @FXML private TextField recherche;
     private ObservableList<Fidelite> fideliteList;
    ServiceFidelite es = new ServiceFidelite();
       private int as ;
    @FXML
    private Button add1;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         // TODO
     
        
  ServiceFidelite es = new ServiceFidelite();
        
        List<Fidelite> le = new ArrayList<>();
        le = (ArrayList<Fidelite>) es.Afficher();
        
        ObservableList<Fidelite> data = FXCollections.observableArrayList(le);
         
           
            System.out.println(data);
        ref.setCellValueFactory(new PropertyValueFactory<Fidelite,Integer>("ref"));
        id_client.setCellValueFactory(new PropertyValueFactory<Fidelite,Integer>("id_client"));
        point.setCellValueFactory(new PropertyValueFactory<Fidelite,Integer>("point"));
      
        int nbe=tvFidelite.getItems().size();
          tvFidelite.setItems(data);
        
    } 
            @FXML

    private void ajouterEventAction(ActionEvent event)  {
            
   FXMLLoader loader = new FXMLLoader
                        (getClass()
                         .getResource("AddFidelite.fxml"));
        try {
            Parent root = loader.load();
            add.getScene().setRoot(root);
                            
        } catch (IOException ex) {
            Logger.getLogger(ServiceFidelite.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
        private void TableEvent(ActionEvent event) {
        
        
        tvFidelite.getSelectionModel().getSelectedItem();   
     }
     
        @FXML
    private void modifierEventAction(ActionEvent event) throws IOException, SQLException  {
             Fidelite e=tvFidelite.getSelectionModel().getSelectedItem();
      System.out.println(e);
if(e==null){
        
           System.out.println("Aucun fidelite séléctionné");
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Aucun fidelite séléctionné");

            alert.showAndWait();
     
        }else {
 
        FXMLLoader loader = new FXMLLoader
                        (getClass()
                         .getResource("ModifyFidelite.fxml"));
        Scene scene=new Scene(loader.load());
        

      
    ModifyFideliteController mc= loader.getController();
        Stage stageAff=new Stage();
        stageAff.setScene(scene);
        stageAff.show();
        ((Node) (event.getSource())).getScene().getWindow().hide();
        as=tvFidelite.getSelectionModel().getSelectedItem().getRef();
        int ref = tvFidelite.getSelectionModel().getSelectedItem().getPoint();
         int id_client = tvFidelite.getSelectionModel().getSelectedItem().getId_client();
        int point = tvFidelite.getSelectionModel().getSelectedItem().getPoint();
      //  Date date_fin = tvFidelite.getSelectionModel().getSelectedItem().getDate_fin();
      
        mc.setData(
                 tvFidelite.getSelectionModel().getSelectedItem().getRef(),
                 tvFidelite.getSelectionModel().getSelectedItem().getId_client(),
                 tvFidelite.getSelectionModel().getSelectedItem().getPoint()
                // tvPromo.getSelectionModel().getSelectedItem().getDate_fin()
                
        );
        loadData();
        refresh();
      
}
        }
  
    private void setCellTableNormale() throws SQLException, MalformedURLException {
            
  ObservableList<Fidelite>data=FXCollections.observableArrayList();

   data.addAll(es.Afficher());
   System.out.println(data.size());
        System.out.println(ref);
        loadData();

            ref.setCellValueFactory(new PropertyValueFactory<>("ref"));
                       
         id_client.setCellValueFactory(new PropertyValueFactory<>("id_client"));

            point.setCellValueFactory(new PropertyValueFactory<>("point"));
      
        tvFidelite.setItems(data); 
        
    }
    
     
    public void loadData() throws SQLException, MalformedURLException{
    ObservableList<Fidelite> dataa = null;

    dataa = FXCollections.observableArrayList(new ServiceFidelite().lister());
    
    }
    
    void refresh() throws SQLException {
     
           ServiceFidelite es = new ServiceFidelite();
        

           ArrayList<Fidelite> le;
       
            le = (ArrayList<Fidelite>) es.Afficher();
            ObservableList<Fidelite> data = FXCollections.observableArrayList(le);
            ref.setCellValueFactory(new PropertyValueFactory<>("ref"));
       
            id_client.setCellValueFactory(new PropertyValueFactory<>("id_client"));

            tvFidelite.setItems(data);
       
           
    }
           
    @FXML

        private void SupprimerEventAction(ActionEvent event) throws SQLException {
            Fidelite e=tvFidelite.getSelectionModel().getSelectedItem();
        
        if(e==null){
        
           System.out.println("Aucun fidelite séléctionné");
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Aucun fidelite séléctionné");

            alert.showAndWait();
     
        }else {
            ServiceFidelite es=new ServiceFidelite();
            try {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Supprimer fidelite");
                alert.setHeaderText(null);
                alert.setContentText("Etes-vous sur de vouloir supprimer fidelite ");
                Optional<ButtonType> action = alert.showAndWait();
                if (action.get() == ButtonType.OK) {
                    // System.out.println("sup1");
                    es.Supprimer(e);
                    Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                    alert1.setTitle("Succés!");
                    alert1.setHeaderText(null);
                    alert1.setContentText("Fidelite supprimé!");

                    alert1.showAndWait();
                             loadData();
         refresh();
                }
            } catch (Exception ex) {
            Logger.getLogger(ServiceFidelite.class.getName()).log(Level.SEVERE, null, ex);
            }
        

        }
        
        }
         private void EnvoyerEventAction(ActionEvent event)  {
            
   FXMLLoader loader = new FXMLLoader
                        (getClass()
                                .getResource("Mail.fxml"));
        try {
            Parent root = loader.load();
            add.getScene().setRoot(root);
                            
        } catch (IOException ex) {
            Logger.getLogger(ServiceFidelite.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
         @FXML
           private void EnvoyerMailAction(ActionEvent event)  {
            
   FXMLLoader loader = new FXMLLoader
                        (getClass()
                                .getResource("Mail.fxml"));
        try {
            Parent root = loader.load();
            add.getScene().setRoot(root);
                            
        } catch (IOException ex) {
            Logger.getLogger(ServiceFidelite.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
/*public void searching() {
        // TODO
       
        ref.setCellValueFactory(new PropertyValueFactory<>("ref"));
        id_client.setCellValueFactory(new PropertyValueFactory<>("id_client"));
        point.setCellValueFactory(new PropertyValueFactory<>("point"));
   
        ObservableList<Fidelite>fideliteList = FXCollections.observableArrayList();
       
        connection = DbConnect.getConnect();
        String query = "SELECT * FROM fidelite";
        Statement st;
        ResultSet rs;
        
        try{
            st = connection.createStatement();
            rs = st.executeQuery(query);
            Fidelite fidelite;
            while(rs.next()){
               fidelite = new Fidelite(rs.getInt("ref"),rs.getInt("id_client"), rs.getInt("point"));
                fideliteList.add(fidelite);
            }
                
        }catch(Exception ex){
            ex.printStackTrace();
        }
      
        FilteredList<Fidelite> filteredData = new FilteredList<>( fideliteList, b -> true);
	
		recherche.textProperty().addListener((observable, oldValue, newValue) -> {
			filteredData.setPredicate(fidelite -> {
		
				if (newValue == null || newValue.isEmpty()) {
					return true;
				}
				
				String lowerCaseFilter = newValue.toLowerCase();
				
				if (String.valueOf(fidelite.getRef()).contains(lowerCaseFilter)) {
					return true; // Filter matches first name.
				} else if (String.valueOf(fidelite.getId_client()).contains(lowerCaseFilter)) {
					return true; // Filter matches last name.
				}
				else if (String.valueOf(fidelite.getPoint()).contains(lowerCaseFilter))
				     return true;
				     else  
				    	 return false; // Does not match.
			});
		});
		
		// 3. Wrap the FilteredList in a SortedList. 
		SortedList<Fidelite> sortedData = new SortedList<>(filteredData);
		
		// 4. Bind the SortedList comparator to the TableView comparator.
		// 	  Otherwise, sorting the TableView would have no effect.
		sortedData.comparatorProperty().bind(tvFidelite.comparatorProperty());
		
		// 5. Add sorted (and filtered) data to the table.
		tvFidelite.setItems(sortedData);
      
               
    } */ 
          
       /*   private void searchK(KeyEvent event) throws MalformedURLException {
              
       ServiceFidelite produitService = new ServiceFidelite();
        ArrayList arrayList = (ArrayList) produitService.lister();
        ObservableList observableList = FXCollections.observableArrayList(arrayList);
        listcategorie.setItems(observableList);
        ref.setCellValueFactory(new PropertyValueFactory<>("ref"));
        id_client.setCellValueFactory(new PropertyValueFactory<>("id_client"));
        point.setCellValueFactory(new PropertyValueFactory<>("point"));
       // image.setCellValueFactory(new PropertyValueFactory<>("image"));

        Callback<TableColumn<Fidelite, String>, TableCell<Fidelite, String>> cellFactoryImage
                = //
                new Callback<TableColumn<Fidelite, String>, TableCell<Fidelite, String>>() {
            @Override
            public TableCell call(final TableColumn<Categoris, String> param) {
                final TableCell<Categoris, String> cell = new TableCell<Categoris, String>() {

                    @Override
                    public void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                            setText(null);
                        } else {
                            ImageView imagev = new ImageView(new Image(item));
                            imagev.setFitHeight(100);
                            imagev.setFitWidth(100);
                            setGraphic(imagev);
                            setText(null);
                            //System.out.println(item);
                        }
                    }
                };
                return cell;
            }
        };

        image.setCellFactory(cellFactoryImage);
    }*/
}
   

    
   
