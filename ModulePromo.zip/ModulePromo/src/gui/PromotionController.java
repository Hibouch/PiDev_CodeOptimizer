/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;
import com.esprit.utils.DataSource;
import com.esprit.models.Promotion;
import com.esprit.services.ServicePromotion;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.scene.control.TextField;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javax.sql.rowset.serial.SerialArray;
import javax.swing.text.Document;

/**
 * FXML Controller class
 *
 * @author infoMix
 */
public class PromotionController implements Initializable {
    
     int index = -1;
    @FXML private TableView<Promotion> tvPromo;
    @FXML private TableColumn<Promotion, Integer> pourcentage;
    @FXML private TableColumn<Promotion, Date> date_debut;
    @FXML private TableColumn<Promotion,Date > date_fin;
    @FXML private Button add;
    @FXML private Button Modifiy;
    @FXML private Button remove;
    @FXML private TextField recherche;
     private ObservableList<Promotion> promoList;
    ServicePromotion es = new ServicePromotion();
       private int as ;
    @FXML
    private Button mail;
    @FXML
    private Button add2;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         // TODO
     
        
  ServicePromotion es = new ServicePromotion();
        
        List<Promotion> le = new ArrayList<>();
        le = (ArrayList<Promotion>) es.Afficher();
        
        ObservableList<Promotion> data = FXCollections.observableArrayList(le);
         
           
            System.out.println(data);
        pourcentage.setCellValueFactory(new PropertyValueFactory<Promotion,Integer>("pourcentage"));
        date_debut.setCellValueFactory(new PropertyValueFactory<Promotion,Date>("date_debut"));
        date_fin.setCellValueFactory(new PropertyValueFactory<Promotion,Date>("date_fin"));
      
        int nbe=tvPromo.getItems().size();
          tvPromo.setItems(data);
        
    } 
            @FXML

    private void ajouterEventAction(ActionEvent event)  {
            
   FXMLLoader loader = new FXMLLoader
                        (getClass()
                         .getResource("AddPromotion.fxml"));
        try {
            Parent root = loader.load();
            add.getScene().setRoot(root);
                            
        } catch (IOException ex) {
            Logger.getLogger(ServicePromotion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    
        private void TableEvent(ActionEvent event) {
        
        
        tvPromo.getSelectionModel().getSelectedItem();   
     }
     
        @FXML
    private void modifierEventAction(ActionEvent event) throws IOException  {
             Promotion e=tvPromo.getSelectionModel().getSelectedItem();
      System.out.println(e);
if(e==null){
        
           System.out.println("Aucun promotion séléctionné");
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Aucun promotion séléctionné");

            alert.showAndWait();
     
        }else {
 
        FXMLLoader loader = new FXMLLoader
                        (getClass()
                         .getResource("ModifyPromotion.fxml"));
        Scene scene=new Scene(loader.load());
        

      
    ModifyPromotionController mc= loader.getController();
        Stage stageAff=new Stage();
        stageAff.setScene(scene);
        stageAff.show();
        ((Node) (event.getSource())).getScene().getWindow().hide();
        as=tvPromo.getSelectionModel().getSelectedItem().getId_promo();
        int pourcentage = tvPromo.getSelectionModel().getSelectedItem().getPourcentage();
        Date date_debut = tvPromo.getSelectionModel().getSelectedItem().getDate_debut();
        Date date_fin = tvPromo.getSelectionModel().getSelectedItem().getDate_fin();
      
        mc.setData(
                 tvPromo.getSelectionModel().getSelectedItem().getId_promo(),
                 tvPromo.getSelectionModel().getSelectedItem().getPourcentage(),
                 tvPromo.getSelectionModel().getSelectedItem().getDate_debut(),
                 tvPromo.getSelectionModel().getSelectedItem().getDate_fin()
                
        );
      
}
        }
  
    private void setCellTableNormale() throws SQLException, MalformedURLException {
            
  ObservableList<Promotion>data=FXCollections.observableArrayList();

   data.addAll(es.Afficher());
   System.out.println(data.size());
        System.out.println(pourcentage);
        loadData();

            pourcentage.setCellValueFactory(new PropertyValueFactory<>("pourcentqge"));
                       
         date_debut.setCellValueFactory(new PropertyValueFactory<>("date_debut"));

            date_fin.setCellValueFactory(new PropertyValueFactory<>("date_fin"));
      
        tvPromo.setItems(data); 
        
    }
    
     
    public void loadData() throws SQLException, MalformedURLException{
    ObservableList<Promotion> dataa = null;

    dataa = FXCollections.observableArrayList(new ServicePromotion().lister());
    
    }
    
    void refresh() throws SQLException {
     
           ServicePromotion es = new ServicePromotion();
        

           ArrayList<Promotion> le;
       
            le = (ArrayList<Promotion>) es.Afficher();
            ObservableList<Promotion> data = FXCollections.observableArrayList(le);
            pourcentage.setCellValueFactory(new PropertyValueFactory<>("pourcentage"));
       
            date_debut.setCellValueFactory(new PropertyValueFactory<>("date_debut"));

            date_fin.setCellValueFactory(new PropertyValueFactory<>("date_fin"));
         
            tvPromo.setItems(data);
       
           
    }
            @FXML

        private void SupprimerEventAction(ActionEvent event) throws SQLException {
            Promotion e=tvPromo.getSelectionModel().getSelectedItem();
        
        if(e==null){
        
           System.out.println("Aucun Promotion séléctionné");
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Aucun Promotion séléctionné");

            alert.showAndWait();
     
        }else {
            ServicePromotion es=new ServicePromotion();
            try {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Supprimer Promotion");
                alert.setHeaderText(null);
                alert.setContentText("Etes-vous sur de vouloir supprimer promotion ");
                Optional<ButtonType> action = alert.showAndWait();
                if (action.get() == ButtonType.OK) {
                    // System.out.println("sup1");
                    es.Supprimer(e);
                    Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                    alert1.setTitle("Succés!");
                    alert1.setHeaderText(null);
                    alert1.setContentText("Promotion supprimé!");

                    alert1.showAndWait();
                             loadData();
         refresh();
                }
            } catch (Exception ex) {
            Logger.getLogger(ServicePromotion.class.getName()).log(Level.SEVERE, null, ex);
            }
        

        }
        
        }
         private void EnvoyerEventAction(ActionEvent event)  {
            
   FXMLLoader loader = new FXMLLoader
                        (getClass()
                                .getResource("Mail.fxml"));
        try {
            Parent root = loader.load();
            add.getScene().setRoot(root);
                            
        } catch (IOException ex) {
            Logger.getLogger(ServicePromotion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
         @FXML
           private void EnvoyerMailAction(ActionEvent event)  {
            
   FXMLLoader loader = new FXMLLoader
                        (getClass()
                                .getResource("Mail.fxml"));
        try {
            Parent root = loader.load();
            add.getScene().setRoot(root);
                            
        } catch (IOException ex) {
            Logger.getLogger(ServicePromotion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    @FXML
            private void CalculatorEventAction(ActionEvent event)  {
            
   FXMLLoader loader = new FXMLLoader
                        (getClass()
                         .getResource("Calculator.fxml"));
        try {
            Parent root = loader.load();
            add.getScene().setRoot(root);
                            
        } catch (IOException ex) {
            Logger.getLogger(ServicePromotion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
           
   /* @FXML
    private void telecharger(ActionEvent event) throws IOException,FileNotFoundException, DocumentException, SQLException  {
        
            String file_name="C:\\Users\\PC\\Desktop\\PiDev\\TechPhantoms.pdf";
            Document document = new Document() {};
            
            PdfWriter.getInstance(document, new FileOutputStream(file_name));
            
            document.open();
            DataSource db = new DataSource();
            Connection cnx = db.getCnx();
            PreparedStatement ps =null;
            ResultSet rs =null;
            String req = "Select * from matiere ";
            ps = cnx.prepareCall(req);
            rs=ps.executeQuery();
            
            PdfPTable t = new PdfPTable(5);
            
            PdfPCell c1 = new PdfPCell(new Phrase("Id"));
            t.addCell(c1);
            PdfPCell c2 = new PdfPCell(new Phrase("Nom"));
            t.addCell(c2);
            PdfPCell c3 = new PdfPCell(new Phrase("Type"));
            t.addCell(c3);
            PdfPCell c4 = new PdfPCell(new Phrase("Disponibilty"));
            t.addCell(c4);
             PdfPCell c5 = new PdfPCell(new Phrase("Id_teacher"));
            t.addCell(c5);
            t.setHeaderRows(1);
          try {
            while(rs.next()){
                t.addCell(rs.getString(1));
                t.addCell(rs.getString(2));
                t.addCell(rs.getString(3));
                t.addCell(rs.getString(4));
                t.addCell(rs.getString(5));
                
            }
            document.add(t);
            document.close();
            System.out.println("finished");
        } catch (DocumentException ex) {
            System.out.println(ex); 
        }
  
    }*/

    
           
}
   

    
   
