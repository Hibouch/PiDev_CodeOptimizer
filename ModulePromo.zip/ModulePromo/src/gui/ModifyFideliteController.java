                                                                                                                                                                /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import com.esprit.models.Fidelite;
//import com.esprit.models.Promotion;
import com.esprit.services.ServiceFidelite;
//import com.esprit.services.ServicePromotion;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import static java.time.zone.ZoneRulesProvider.refresh;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author infoMix
 */
public class ModifyFideliteController implements Initializable {
    @FXML
    private TextField id_client;
    @FXML
    private Button btSaveF;
    @FXML
    private TextField point;
    @FXML
    private TextField ref;

     Fidelite e;
    Fidelite ev = new Fidelite();
    @FXML
    private AnchorPane anchorPane;
    
    /**
     * Initializes the controller class.
     */
    @Override
       public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        //cbnCategories.setItems(options);
   
    }
    
    @FXML
    private void Modifiy(ActionEvent event) throws SQLException, IOException {
                
      if (Integer.parseInt(point.getText())<1 || (Integer.parseInt(point.getText())> 1000))
         {
             Alert alert3 = new Alert(Alert.AlertType.WARNING);
            alert3.setTitle(null);
            alert3.setHeaderText("WARNING !");
            alert3.setContentText("veuillez saisir un valeur entre 0 et 1000  !!");
            alert3.showAndWait();  
            
           }else {
                 
            ev.setRef(Integer.parseInt(ref.getText()));
             ev.setId_client(Integer.parseInt(id_client.getText()));
           ev.setPoint(Integer.parseInt(point.getText()));
          
          

         //a mmodifier !!!!
            try {

               ServiceFidelite es = new ServiceFidelite();
                System.out.println("az............");

                System.out.println(ev.toString());
               es.Modifier(ev);
               AnchorPane pane   = FXMLLoader.load(getClass().getResource("Fidelite.fxml"));
  
                Stage stage = new Stage();
                 stage.setScene(new Scene(pane));
                 stage.show();     

        } catch (Exception ex) {
                
                ex.printStackTrace();
        }
            System.out.println("Modification terminé");
           
   
        
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Fidelite enregistré avec succès.");
        alert.setHeaderText(null);

        alert.showAndWait();
        refresh();
        }
    
   
    
    }
    void setData(int reff, int id_clientt, int pointt) {
       ev.setRef(reff);
       ref.setText(String.valueOf(reff));
       id_client.setText(String.valueOf(id_clientt));
       point.setText(String.valueOf(pointt));           }
       
     
   
}

  